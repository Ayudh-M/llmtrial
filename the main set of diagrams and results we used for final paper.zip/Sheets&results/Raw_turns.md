🗣️ Raw Turns Analysis Report

A total of 1,304 dialogue turns from 148 run records.

Average latency per turn: 4.84s

Average input tokens: 470.1

Average output tokens: 126.7

Average raw output length: 438.6 characters

JSON parse success rate: 23.1%

Percentage of outputs containing extra text: 6.4%


📊 Content Tag Distribution

The most frequent tag: Boolean Evaluation

