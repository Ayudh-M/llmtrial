⚙️ Token & Latency Analysis Report

Total run records: 163

Average input tokens: 3760.5

Average output tokens: 1013.4

Average total tokens: 4773.9

Average response time: 4.84s

95th percentile response time: 5.10s

Average truncation count: 6.30

📊 Dataset Performance

Fastest responding dataset: boolean_eval_small (average 4.19s)

Slowest responding dataset: regex_email_basic (average 5.07s)

