🧾 Automated Experiment Summary Report

This experiment includes 163 run records,
covering 12 datasets, 6 language strategies,
and 11 model pairs.

The overall average success rate is 100.0%,
with an average runtime of 38.7 seconds
and an average of 8.0 dialogue turns.

📈 Dataset Performance

The best-performing dataset is boolean_eval_small (success rate 100.0%, average runtime 33.5s).

The least efficient dataset is writer_physicist_tiny (success rate 100.0%, average runtime 40.5s).

