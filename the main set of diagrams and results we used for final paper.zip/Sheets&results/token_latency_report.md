
# ⚙️ Token & Latency Analysis Report (with Strategy Dimension)

- Total run records: **163**
- Average input tokens: **3760.5**
- Average output tokens: **1013.4**
- Average total tokens: **4773.9**
- Average response time: **4.84s**
- 95th percentile latency: **5.10s**
- Average truncations: **6.30**

## 📊 Task Performance
- Fastest task: **Boolean Evaluation** (avg 4.33s)
- Slowest task: **Regex Authoring** (avg 5.07s)

## 🌍 Strategy Performance
- `language_avg_latency.png` — Average latency across strategies.
- `task_language_latency_heatmap.png` — Latency heatmap across Task × Strategy.

## 🔍 Additional Visualizations
- `tokens_vs_latency.png` — Tokens vs Average Latency.
- `dataset_avg_latency.png` — Task-wise Average Latency Comparison.
